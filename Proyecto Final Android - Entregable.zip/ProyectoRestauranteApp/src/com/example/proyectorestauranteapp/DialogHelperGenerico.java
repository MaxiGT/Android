package com.example.proyectorestauranteapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

public class DialogHelperGenerico extends DialogFragment {
	
	static DialogHelperGenerico newInstance(String title, String optionYes, String optionNo, String actName){
		DialogHelperGenerico fragment = new DialogHelperGenerico();
        Bundle args = new Bundle();
        args.putString("title", title);
        args.putString("si", optionYes);
        args.putString("no", optionNo);
        args.putString("actividad", actName);
        fragment.setArguments(args);
        return fragment;
	}
	
	public Dialog onCreateDialog(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        String title = getArguments().getString("title");
        String optionNo = getArguments().getString("no");
        String optionYes = getArguments().getString("si");
        final String actName = getArguments().getString("actividad");
        	
       	return new AlertDialog.Builder(getActivity())
        .setIcon(R.drawable.ic_launcher)
        .setTitle(title)
        .setPositiveButton(optionYes, new DialogInterface.OnClickListener() {
             
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (actName == "MainActivity") {
                	((MainActivity)getActivity()).doPositiveClick();
                } else if (actName == "MisRestaurantesActivity") {
                	((MisRestaurantesActivity)getActivity()).doPositiveClick();
                } else if (actName == "VerTopTenActivity") {
                	((VerTopTenActivity)getActivity()).doPositiveClick();
                }
                
            }
        })
        .setNegativeButton(optionNo, new DialogInterface.OnClickListener() {
             
            @Override
            public void onClick(DialogInterface dialog, int which) {
            	if (actName == "MainActivity") {
            		((MainActivity)getActivity()).doNegativeClick();
            	} else if (actName == "MisRestaurantesActivity") {
            		((MisRestaurantesActivity)getActivity()).doNegativeClick();
            	} else if (actName == "VerTopTenActivity") {
                	((VerTopTenActivity)getActivity()).doNegativeClick();
                }
            }
        })
    .create();
    	
    }       
}
