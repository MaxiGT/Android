package com.example.proyectorestauranteapp;

import android.graphics.PointF;

public class RegistroDB {
	
	Integer id;
	String nombre;
	String direccion;
	String observaciones;
	String foto;
	String telefono;
	Float rate;
	Double distancia;
	
	public RegistroDB(Integer id, String nombre, String direccion, String observaciones, String foto,
	String telefono, Float rate, Double distancia) {
		this.id = id;
		this.nombre = nombre;
		this.direccion = direccion;
		this.observaciones = observaciones;
		this.foto = foto;
		this.telefono = telefono;
		this.rate = rate;
		this.distancia = distancia;
	}

	public Integer getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public String getFoto() {
		return foto;
	}

	public String getTelefono() {
		return telefono;
	}

	public Float getRate() {
		return rate;
	}

	public Double getDistancia() {
		return distancia;
	}

}
