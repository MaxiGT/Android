package com.example.proyectorestauranteapp;

import java.util.ArrayList;
import java.util.Locale;

import org.json.JSONObject;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.R.string;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class AgregarRestauranteActivity extends Activity {
	
	private RestauranteDB dbHelper;
	private Location location;
	private Location googleLocation;
	private GoogleConnectionHelper GPSHelper;
	private GeocoderHelper geoHelper;
	private Bitmap bmp;
	private ImageView imgAgregar;
	private String fotoPath;
	
	private GoogleMap map;
	private LatLng positionMarker;
	
	private static final Integer CAMERA_CODE = 01;
	private static final String DB_QUERY_VALIDATION = "SELECT * FROM restaurante WHERE nombre = '";
	
	@Override
	protected void onStart() {
		GPSHelper = GoogleConnectionHelper.getInstance(this);
		
		super.onStart();
	}
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_agregar_restaurante);
		
		final ArrayList<Long> ids = new ArrayList<Long>();
		
		map = ((MapFragment)getFragmentManager().findFragmentById(R.id.fragment_map_agregar)).getMap();
		
		final EditText edtNombre = (EditText)findViewById(R.id.nombreAgregar);
		final EditText edtDireccion = (EditText)findViewById(R.id.direccionAgregar);
		final EditText edtTelefono = (EditText)findViewById(R.id.telefonoAgregar);
		final EditText edtObservaciones = (EditText)findViewById(R.id.observacionesAgregar);
		final RatingBar rtRate = (RatingBar)findViewById(R.id.rateAgregar);
		imgAgregar = (ImageView)findViewById(R.id.imgAgregar);
		
		final Button btnBuscarPosicionActual = (Button)findViewById(R.id.btnMiPosicionActualAgregar);
		final Button btnGuardarAgregar = (Button)findViewById(R.id.btnGuardarAgregar);
		
		edtNombre.setText("");
		edtDireccion.setText("");
		edtTelefono.setText("");
		edtObservaciones.setText("");
		
		onStart();
		
		try {
			dbHelper = new RestauranteDB(getApplicationContext());
			Toast.makeText(getApplicationContext(), "DB creada exitosamente", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "ERROR durante la creacion de la DB", Toast.LENGTH_SHORT).show();
		}
		
		imgAgregar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
				startActivityForResult(i, CAMERA_CODE);
			}
		});
		
		
		btnGuardarAgregar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				if (edtNombre.getText().toString().equalsIgnoreCase(null) || edtNombre.getText().toString().equalsIgnoreCase("")) {
					Toast.makeText(getApplicationContext(), "Nombre Faltante", Toast.LENGTH_LONG).show();
				} else if (edtDireccion.getText().toString().equalsIgnoreCase("") || edtDireccion.getText().toString().equalsIgnoreCase(null)) {
					Toast.makeText(getApplicationContext(), "Direccion Faltante", Toast.LENGTH_LONG).show();
				} else if (edtObservaciones.getText().toString().equalsIgnoreCase("") || edtObservaciones.getText().toString().equalsIgnoreCase(null)) {
					Toast.makeText(getApplicationContext(), "Observaciones Faltante", Toast.LENGTH_LONG).show();
				} else if (rtRate.getRating() == 0.0f) {
					Toast.makeText(getApplicationContext(), "Rate Invalido", Toast.LENGTH_LONG).show();
				} else {
					
					dbHelper = new RestauranteDB(getApplicationContext());
					SQLiteDatabase db = dbHelper.getWritableDatabase();
					
					ContentValues values = new ContentValues();
					values.put("nombre", edtNombre.getText().toString());
					values.put("direccion", edtDireccion.getText().toString());
					values.put("observaciones", edtObservaciones.getText().toString());
					values.put("foto", fotoPath);
					values.put("telefono", edtTelefono.getText().toString());
					values.put("rate", rtRate.getRating());
					
					try {
						long newRowInserted = db.insert("restaurante", null, values);
						ids.add(newRowInserted);
						Toast.makeText(getApplicationContext(), "Restaurante insertado", Toast.LENGTH_SHORT).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(), "Fallo al insertar", Toast.LENGTH_SHORT).show();
					}
					
					edtNombre.setText("");
					edtDireccion.setText("");
					edtObservaciones.setText("");
					edtTelefono.setText("");
					rtRate.setRating(0.0f);
					imgAgregar.setImageResource(0);
					edtNombre.requestFocus();
					
					map.clear();
				}
			}
		});
		
		
		edtDireccion.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_SEARCH) {
					EditText edtDireccion = (EditText)findViewById(R.id.direccionAgregar);
					geoHelper = new GeocoderHelper();
					String direccion = edtDireccion.getText().toString();
					googleLocation = geoHelper.getLocation(direccion, getApplicationContext());
					
					map.clear();
					positionMarker = new LatLng(googleLocation.getLatitude(), googleLocation.getLongitude());
					Marker marker = map.addMarker(new MarkerOptions().position(positionMarker).title(edtNombre.getText().toString()).snippet(edtObservaciones.getText().toString()));
					
					map.moveCamera(CameraUpdateFactory.newLatLngZoom(positionMarker, 15));
					map.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);
				}
				return false;
			}
		});

		
		btnBuscarPosicionActual.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				EditText edtDireccion = (EditText)findViewById(R.id.direccionAgregar);
				location = GPSHelper.getActualLocation();
				positionMarker = new LatLng(location.getLatitude(), location.getLongitude());
				
				geoHelper = new GeocoderHelper();
				String address = geoHelper.getLocationAddress(location, getApplicationContext());
				edtDireccion.setText(address);
				
				map.clear();
				positionMarker = new LatLng(location.getLatitude(), location.getLongitude());
				Marker marker = map.addMarker(new MarkerOptions().position(positionMarker).title(edtNombre.getText().toString()).snippet(edtObservaciones.getText().toString()));
				
				map.moveCamera(CameraUpdateFactory.newLatLngZoom(positionMarker, 15));
				map.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);
				
			}
		});
	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == CAMERA_CODE) {	
			if (resultCode == Activity.RESULT_OK) {
				Bundle b = data.getExtras();
				bmp = (Bitmap)b.get("data");
				imgAgregar.setImageBitmap(bmp);
				
				
				Uri selectedImage = data.getData();
				String[] filePathColumn = {MediaStore.Images.Media.DATA};
				
				Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
				cursor.moveToFirst();
				
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				fotoPath = cursor.getString(columnIndex);
				cursor.close();
			}
		}
	}
}
