package com.example.proyectorestauranteapp;

import java.text.DecimalFormat;
import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class AdapterLista extends BaseAdapter {
	
	private Context context;
	private ArrayList<RegistroDB> registro;
	
	public AdapterLista(Context context, ArrayList<RegistroDB> registro) {
		this.context = context;
		this.registro = registro;
		
	}

	public void addItem(RegistroDB nuevoRegistro) {
		this.registro.add(nuevoRegistro);
	}
	
	@Override
	public int getCount() {
		return registro.size();
	}

	@Override
	public Object getItem(int position) {
		return registro.get(position);
	}

	@Override
	public long getItemId(int position) {
		return registro.get(position).getId();
	}
	
	public void removeItem(int position) {
		registro.remove(position);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		if (convertView == null) {
			LayoutInflater inflator = LayoutInflater.from(context);
			convertView = inflator.inflate(R.layout.lista_custom, parent, false);			
		}
			TextView txtNombre = (TextView)convertView.findViewById(R.id.nombreLista);
			txtNombre.setText(registro.get(position).getNombre().toString());
			
			TextView txtDireccion = (TextView)convertView.findViewById(R.id.direccionLista);
			txtDireccion.setText(registro.get(position).getDireccion().toString());
			
			if (registro.get(position).getFoto() != null && registro.get(position).getFoto() != "") {
				try {
					ImageView imgLista = (ImageView)convertView.findViewById(R.id.imageLista);
					Bitmap bmp = BitmapFactory.decodeFile(registro.get(position).getFoto());
					bmp = Bitmap.createScaledBitmap(bmp, 85, 85, false);
					imgLista.setImageBitmap(bmp);
						
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
			
			TextView txtTelefono = (TextView)convertView.findViewById(R.id.telefonoLista);
			txtTelefono.setText(registro.get(position).getTelefono().toString());
			
			RatingBar rateLista = (RatingBar)convertView.findViewById(R.id.rateLista);
			rateLista.setRating(registro.get(position).getRate().floatValue());
			
			
			TextView txtDistanciaLista = (TextView)convertView.findViewById(R.id.distanciaLista);
			if (registro.get(position).getDistancia() != null && registro.get(position).getDistancia() != 0.0) {
				DecimalFormat df = new DecimalFormat("##.00");
				txtDistanciaLista.setText("Distancia:" + df.format(registro.get(position).getDistancia()).toString() + "mt");
			} else {
				txtDistanciaLista.setText("Imposible de calcular en este momento");
			}
			
		return convertView;
	}
}
