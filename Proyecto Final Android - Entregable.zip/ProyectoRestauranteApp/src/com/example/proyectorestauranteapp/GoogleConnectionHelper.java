package com.example.proyectorestauranteapp;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

public class GoogleConnectionHelper implements ConnectionCallbacks, OnConnectionFailedListener, LocationListener, com.google.android.gms.location.LocationListener {

	private static GoogleConnectionHelper instance = null;
	
	private Location LastLocation;
	private Location ActualLocation;
	private LocationRequest LocationRequest;
	private GoogleApiClient GoogleApiClient;
	
	protected GoogleConnectionHelper(Context context) {
		
		GoogleApiClient = new GoogleApiClient.Builder(context)
	    .addConnectionCallbacks(this)
	    .addOnConnectionFailedListener(this)
	    .addApi(LocationServices.API).build();
		
		try {
			GoogleApiClient.connect();
			Toast.makeText(context, "Conexion establecida", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			Toast.makeText(context, "ERROR al establecer conexion", Toast.LENGTH_SHORT).show();
		}
	}
	
	public static GoogleConnectionHelper getInstance(Context context) {
		if (instance == null) {
			instance = new GoogleConnectionHelper(context);
		}
		return instance;
	}
	
	
	
	@Override
	public void onLocationChanged(Location location) {
		LastLocation = ActualLocation;
		ActualLocation = location;
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("static-access")
	@Override
	public void onConnected(Bundle connectionHint) {
		LocationRequest = new LocationRequest();
        LocationRequest.setInterval(1000);
        LocationRequest.setFastestInterval(10);
        LocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        
        try {
			LocationServices.FusedLocationApi.requestLocationUpdates(
					GoogleApiClient, LocationRequest, this);
			
			LastLocation = LocationServices.FusedLocationApi.getLastLocation(GoogleApiClient);
			ActualLocation = LocationServices.FusedLocationApi.getLastLocation(GoogleApiClient);
			
			//Toast.makeText(context, "Correctamente configurado", Toast.LENGTH_SHORT).show();
		} catch (Exception e) {
			//Toast.makeText(context, "ERROR durante la configuracion", Toast.LENGTH_SHORT).show();
		}
        
	}

	@Override
	public void onConnectionSuspended(int cause) {
		// TODO Auto-generated method stub
		
	}

	public Location getLastLocation() {
		LastLocation = LocationServices.FusedLocationApi.getLastLocation(GoogleApiClient);
		return LastLocation;
	}
	
	public Location getActualLocation() {
		ActualLocation = LocationServices.FusedLocationApi.getLastLocation(GoogleApiClient);
		return ActualLocation;
	}
	
}
