package com.example.proyectorestauranteapp;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends FragmentActivity implements ConnectionCallbacks, OnConnectionFailedListener,
LocationListener {
	
	private GoogleConnectionHelper GPSHelper;
	
	@Override
	protected void onStart() {
		GPSHelper = GoogleConnectionHelper.getInstance(this);
		super.onStart();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Button btnMisRestaurates = (Button)findViewById(R.id.btnMisRestaurantes);
		Button btnTopTen = (Button)findViewById(R.id.btnTopTen);
		Button btnAgregar = (Button)findViewById(R.id.btnAgregar);
		Button btnVerMapa = (Button)findViewById(R.id.btnVerMapa);
		
		onStart();
		
		btnMisRestaurates.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
			Intent intent = new Intent(getApplicationContext(), MisRestaurantesActivity.class);
			startActivity(intent);
			}
		});
		
		btnTopTen.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), VerTopTenActivity.class);
				startActivity(intent);
			}
		});
		
		btnAgregar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), AgregarRestauranteActivity.class);
				startActivity(intent);
			}
		});
		
		btnVerMapa.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), VerTodosActivity.class);
				startActivity(intent);
			}
		});
	}
	
	@Override
	public void onBackPressed() {
		DialogHelperGenerico dialogFragment = DialogHelperGenerico
                .newInstance("�Desea cerrar la aplicacion?", "Si", "No", "MainActivity");
        dialogFragment.show(getSupportFragmentManager(), "dialog");
	}
	
	public void doPositiveClick(){
		super.onBackPressed();
    }
     
    public void doNegativeClick(){
        
    }   
	
	
	
	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnected(Bundle connectionHint) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionSuspended(int cause) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionFailed(ConnectionResult arg0) {
		// TODO Auto-generated method stub
		
	}
	


}
