package com.example.proyectorestauranteapp;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

public class DetalleActivity extends Activity {
	
	private static final String DB_COLUMN_1 = "id";
	private static final String DB_COLUMN_2 = "nombre";
	private static final String DB_COLUMN_3 = "direccion";
	private static final String DB_COLUMN_4 = "observaciones";
	private static final String DB_COLUMN_5 = "foto";
	private static final String DB_COLUMN_6 = "telefono";
	private static final String DB_COLUMN_7 = "rate";
	
	private static Integer CAMERA_CODE = 0;
	
	private RestauranteDB dbHelper;
	private SQLiteDatabase db;
	private Intent intent = new Intent();
	private Bundle b = new Bundle();
	
	private String fotoPath;
	private Bitmap bmp;
	private ImageView imgDetalle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detalle);
		
		//Input INTENT - Contiene informacion de detalle
		b = this.getIntent().getExtras();
		
		//CONTROLES OBLIGATORIOS
		final EditText edtNombreDetalle = (EditText)findViewById(R.id.nombreDetalle);
		final EditText edtDireccionDetalle = (EditText)findViewById(R.id.direccionDetalle);
		final EditText edtObservacionesDetalle = (EditText)findViewById(R.id.observacionesDetalle);
		final RatingBar rtRateDetalle = (RatingBar)findViewById(R.id.rateDetalle);
		
		//CONTROLES NO OBLIGATORIOS
		final EditText edtTelefonoDetalle = (EditText)findViewById(R.id.telefonoDetalle);
		imgDetalle = (ImageView)findViewById(R.id.imgDetalle);
		
		//BOTONES
		Button btnEditarDetalle = (Button)findViewById(R.id.btnEditarDetalle);
		Button btnIrHastaDetalle = (Button)findViewById(R.id.btnIrHastaRestauranteDetalle);
		final Button btnGuardarDetalle = (Button)findViewById(R.id.btnGuardarDetalle);
		
		//Se ocultan aquellos controles NO Obligatorios que no contengan informacion
		//Debido a que se valida al momento de guardar, NOMBRE, DIRECCION, OBSERVACIONES y RATE no deberian estar vacios
		try {
			edtNombreDetalle.setText(b.getString(DB_COLUMN_2));
			edtDireccionDetalle.setText(b.getString(DB_COLUMN_3));
			edtObservacionesDetalle.setText(b.getString(DB_COLUMN_4));
			
			if (b.getString(DB_COLUMN_6).equalsIgnoreCase(null) || b.getString(DB_COLUMN_6).equalsIgnoreCase("")) {
				edtTelefonoDetalle.setVisibility(2);
			} else {
				edtTelefonoDetalle.setText(b.getString(DB_COLUMN_6));
			}
			rtRateDetalle.setRating(b.getFloat(DB_COLUMN_7));
			
			if (b.getString(DB_COLUMN_5).equalsIgnoreCase(null) || b.getString(DB_COLUMN_5).equalsIgnoreCase("")) {
				imgDetalle.setVisibility(2);
			} else {
				Bitmap bmp = BitmapFactory.decodeFile(b.getString(DB_COLUMN_5));
				bmp = Bitmap.createScaledBitmap(bmp, 100, 100, false);
				imgDetalle.setImageBitmap(bmp);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
						
		//Al seleccionar EDITAR, se modifica el InpuType de los EditText para poder ser modificados
		btnEditarDetalle.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				btnGuardarDetalle.setEnabled(true);
				
				edtNombreDetalle.setEnabled(true);
				edtDireccionDetalle.setEnabled(true);
				edtTelefonoDetalle.setEnabled(true);
				edtObservacionesDetalle.setEnabled(true);
				rtRateDetalle.setFocusable(true);
				
				edtNombreDetalle.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
				edtDireccionDetalle.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
				edtTelefonoDetalle.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
				edtObservacionesDetalle.setInputType(InputType.TYPE_TEXT_FLAG_IME_MULTI_LINE);
				
				CAMERA_CODE = 1;
			}
		});
		
		//Al seleccionar GUARDAR, se recupera la informacion de todos los controles y se realiza un UPDATE sobre la tabla.
		btnGuardarDetalle.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				//Se recuperan los valores del INTENT de Input
				ContentValues values = new ContentValues();
				values.put("nombre", edtNombreDetalle.getText().toString());
				values.put("direccion", edtDireccionDetalle.getText().toString());
				values.put("observaciones", edtObservacionesDetalle.getText().toString());
				values.put("telefono", edtTelefonoDetalle.getText().toString());
				values.put("rate", rtRateDetalle.getRating());
				if (fotoPath != null) {
					values.put("foto", fotoPath);
				}
				
				//Se realiza el Update
				dbHelper = new RestauranteDB(getApplicationContext());
				db = dbHelper.getWritableDatabase();
				int rows = db.update("restaurante", values, "id = " + b.getLong(DB_COLUMN_1), null);
				
				//Se deshabilita el boton Guardar y los EditText se configuran para no ser editables nuevamente
				btnGuardarDetalle.setEnabled(false);
				edtNombreDetalle.setEnabled(false);
				edtDireccionDetalle.setEnabled(false);
				edtTelefonoDetalle.setEnabled(false);
				edtObservacionesDetalle.setEnabled(false);
				
				CAMERA_CODE = 0;
			}
		});
		
		//Al seleccionar IR HASTA, se dispara una Actividad de google que te lleva al Restaurante.
		btnIrHastaDetalle.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				
				Uri gmmIntentUri = Uri.parse("google.navigation:q=" + edtDireccionDetalle.getText().toString());
				Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
				mapIntent.setPackage("com.google.android.apps.maps");
				startActivity(mapIntent);
				
			}
		});
		
		imgDetalle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if (CAMERA_CODE == 1) {
					Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
					startActivityForResult(i, CAMERA_CODE);
				}
			}
		});
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (requestCode == CAMERA_CODE) {	
			if (resultCode == Activity.RESULT_OK) {
				Bundle b = data.getExtras();
				bmp = (Bitmap)b.get("data");
				imgDetalle.setImageBitmap(bmp);
				
				Uri selectedImage = data.getData();
				String[] filePathColumn = {MediaStore.Images.Media.DATA};
				
				Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
				cursor.moveToFirst();
				
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				fotoPath = cursor.getString(columnIndex);
				cursor.close();
			}
		}
	}
}
