package com.example.proyectorestauranteapp;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PointF;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.renderscript.Float2;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.FloatMath;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;

public class MisRestaurantesActivity extends FragmentActivity implements ConnectionCallbacks, OnConnectionFailedListener,
LocationListener {
	//CONSTANTES
	public static final String DB_COLUMN_1 = "id";
	public static final String DB_COLUMN_2 = "nombre";
	public static final String DB_COLUMN_3 = "direccion";
	public static final String DB_COLUMN_4 = "observaciones";
	public static final String DB_COLUMN_5 = "foto";
	public static final String DB_COLUMN_6 = "telefono";
	public static final String DB_COLUMN_7 = "rate";
	public final static String DB_QUERY_ALL = "SELECT * FROM restaurante ORDER BY nombre ASC";
	//VAR Adapter
	private AdapterLista adapterLista;
	final ArrayList<RegistroDB> datosLista = new ArrayList<RegistroDB>();
	final ArrayList<RegistroDB> datosListaFiltro = new ArrayList<RegistroDB>();
	//VAR Borrado registro
	private int posicionBorrar;
	private Integer idBorrar;
	//VAR GPS
	private GoogleConnectionHelper GPSHelper;
	private RestauranteDB dbHelper;
	private SQLiteDatabase db;
	private Location actualLocation;
	//VAR Geocoder
	private GeocoderHelper GeoHelper;
	private PointF destino = new PointF();
	private PointF actual = new PointF();
	private Location geoLocation;
	//VAR Distancia
	private DistanceHelper mathHelper = new DistanceHelper(); 
	private Double distancia;
	
	@Override
    protected void onStart() {
    	
    	GeoHelper = new GeocoderHelper();
		GPSHelper = GoogleConnectionHelper.getInstance(this);
    	
    	super.onStart();
    }
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mis_restaurantes);
		
		final ListView lstMisRestaurantes = (ListView)findViewById(R.id.listaMisRestaurantes);
		final EditText edtMisRestaurantes = (EditText)findViewById(R.id.edtMisRestaurantes);
		
		onStart();
		
		try {
			
			dbHelper = new RestauranteDB(getApplicationContext());
			db = dbHelper.getWritableDatabase();
			Cursor cursor = db.rawQuery(DB_QUERY_ALL, null);
			cursor.moveToFirst();
			
			while (!cursor.isAfterLast()) {
				
				int IndexID = cursor.getColumnIndex(DB_COLUMN_1);
				Integer id = cursor.getInt(IndexID);
				
				int IndexNombre = cursor.getColumnIndex(DB_COLUMN_2);
				String nombre = cursor.getString(IndexNombre);
				
				int IndexDireccion = cursor.getColumnIndex(DB_COLUMN_3);
				String direccion = cursor.getString(IndexDireccion);
				
				int IndexObservaciones = cursor.getColumnIndex(DB_COLUMN_4);
				String observaciones = cursor.getString(IndexObservaciones);
				
				int IndexFoto = cursor.getColumnIndex(DB_COLUMN_5);
				String foto = cursor.getString(IndexFoto);
				
				int IndexTelefono = cursor.getColumnIndex(DB_COLUMN_6);
				String telefono = cursor.getString(IndexTelefono);
				
				int IndexRate = cursor.getColumnIndex(DB_COLUMN_7);
				Float rate = cursor.getFloat(IndexRate);
				
				try {
					
					geoLocation = GeoHelper.getLocation(direccion, getApplicationContext());
					destino.set(Float.valueOf(String.valueOf(geoLocation.getLatitude())), Float.valueOf(String.valueOf(geoLocation.getLongitude())));
					
					actualLocation = GPSHelper.getActualLocation();
					actual.set(Float.valueOf(String.valueOf(actualLocation.getLatitude())), Float.valueOf(String.valueOf(actualLocation.getLongitude())));
					
					distancia = mathHelper.getDistanceBetweenTwoPoints(actual, destino);
					
				} catch (Exception e) {
					
					distancia = 0.0;
					
				}

				RegistroDB registroNuevo = new RegistroDB(id, nombre, direccion, observaciones, foto, telefono, rate, distancia);
				datosLista.add(registroNuevo);
				
				cursor.moveToNext();
			}
			cursor.moveToFirst();
			cursor.close();
			
			adapterLista = new AdapterLista(this, datosLista);
			lstMisRestaurantes.setAdapter(adapterLista);
			
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "ERROR al asignar el Adapter", Toast.LENGTH_SHORT).show();
		}
		
		
//		lstMisRestaurantes.setOnItemClickListener(new OnItemClickListener() {
//
//			@Override
//			public void onItemClick(AdapterView<?> parent, View view,
//					int position, long id) {
//				try {
//					detalle.put(DB_COLUMN_1, datosLista.get(position).getId());
//					detalle.put(DB_COLUMN_2, datosLista.get(position).getNombre());
//					detalle.put(DB_COLUMN_3, datosLista.get(position).getDireccion());
//					detalle.put(DB_COLUMN_4, datosLista.get(position).getObservaciones());
//					detalle.put(DB_COLUMN_5, datosLista.get(position).getFoto());
//					detalle.put(DB_COLUMN_6, datosLista.get(position).getTelefono());
//					detalle.put(DB_COLUMN_7, datosLista.get(position).getRate());
//					
//					Intent intent = new Intent(getApplicationContext(), DetalleActivity.class);
//					intent.putExtra("detalle", detalle.toString());
//					startActivity(intent);
//				} catch (JSONException e) {
//					Toast.makeText(getApplicationContext(), "JSON ERROR", Toast.LENGTH_SHORT).show();
//				}
//			}
//		});
		
				
		lstMisRestaurantes.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				
				posicionBorrar = position;
				idBorrar = (int) id;
				
				DialogHelperGenerico dialogFragment = DialogHelperGenerico
		                .newInstance("�Que accion desea realizar?", "Eliminar", "Ver Detalle", "MisRestaurantesActivity");
		        dialogFragment.show(getSupportFragmentManager(), "dialog");
				return false;
			}
		});
		
		
		edtMisRestaurantes.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				int textLength = edtMisRestaurantes.getText().toString().length();
				datosListaFiltro.clear();
				
				for (int i = 0; i < datosLista.size(); i++) {
					if (textLength <= datosLista.get(i).getNombre().toString().length()) {
						if (edtMisRestaurantes.getText().toString().equalsIgnoreCase(
						(String) datosLista.get(i).getNombre().toString().subSequence(0, textLength))) {
							datosListaFiltro.add(datosLista.get(i));
						}
					}
				}
				lstMisRestaurantes.setAdapter(new AdapterLista(getApplicationContext(), datosListaFiltro));
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
			}

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
			}
		});
	}

	@Override
	public void onLocationChanged(Location location) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderEnabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onProviderDisabled(String provider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnected(Bundle connectionHint) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionSuspended(int cause) {
		// TODO Auto-generated method stub
		
	}

	public void doPositiveClick(){
		
		int registros = db.delete("restaurante", "id = " + idBorrar, null);
		adapterLista.removeItem(posicionBorrar);
		adapterLista.notifyDataSetChanged();
		
    }
     
    public void doNegativeClick(){
    		
    		Bundle b = new Bundle();
    		b.putLong(DB_COLUMN_1, datosLista.get(posicionBorrar).getId());
    		b.putString(DB_COLUMN_2, datosLista.get(posicionBorrar).getNombre());
			b.putString(DB_COLUMN_3, datosLista.get(posicionBorrar).getDireccion());
			b.putString(DB_COLUMN_4, datosLista.get(posicionBorrar).getObservaciones());
			b.putString(DB_COLUMN_5, datosLista.get(posicionBorrar).getFoto());
			b.putString(DB_COLUMN_6, datosLista.get(posicionBorrar).getTelefono());
    		b.putFloat(DB_COLUMN_7, datosLista.get(posicionBorrar).getRate());
			
			Intent intent = new Intent(getApplicationContext(), DetalleActivity.class);
			intent.putExtras(b);
			startActivity(intent);
        
    }
}