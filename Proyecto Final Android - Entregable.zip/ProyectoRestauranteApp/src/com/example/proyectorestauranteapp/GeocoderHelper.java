package com.example.proyectorestauranteapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.text.TextUtils;

public class GeocoderHelper {
	
	public Location getLocation(String address, Context context) {
		Location location = new Location("hgh");
		Geocoder geocoder = new Geocoder(context, Locale.getDefault());
		try {
			List<Address> direccion = geocoder.getFromLocationName(address, 1);
			
			if (direccion != null) {
				location.setLatitude(direccion.get(0).getLatitude());
				location.setLongitude(direccion.get(0).getLongitude());
			} else {
				location = null;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return location;
	}
	
	
	public String getLocationAddress(Location location, Context context) {
		
		Geocoder geocoder = new Geocoder(context, Locale.getDefault());
		Address fetchedAddress = null;
		String addressResultado = null;
		
		try {
			List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),
					location.getLongitude(), 1);
			
			if (addresses != null) {
				fetchedAddress = addresses.get(0);
				
				ArrayList<String> addressFragments = new ArrayList<String>();
				for(int i = 0; i < fetchedAddress.getMaxAddressLineIndex(); i++) {
		            addressFragments.add(fetchedAddress.getAddressLine(i));
		        }
				
				addressResultado = TextUtils.join(",", addressFragments);
			} else {
				addressResultado = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return addressResultado;
	}
}
