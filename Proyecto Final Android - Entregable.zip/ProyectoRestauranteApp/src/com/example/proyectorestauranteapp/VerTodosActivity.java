package com.example.proyectorestauranteapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class VerTodosActivity extends Activity {
	
	private GoogleMap map;
	
	private RestauranteDB dbHelper;
	private SQLiteDatabase db;
	private final static String DB_QUERY_ALL = "SELECT * FROM restaurante ORDER BY nombre ASC";
	private final static String DB_QUERY_MARKER = "SELECT * FROM restaurante WHERE nombre = '";
	
	private static final String DB_COLUMN_1 = "id";
	private static final String DB_COLUMN_2 = "nombre";
	private static final String DB_COLUMN_3 = "direccion";
	private static final String DB_COLUMN_4 = "observaciones";
	private static final String DB_COLUMN_5 = "foto";
	private static final String DB_COLUMN_6 = "telefono";
	private static final String DB_COLUMN_7 = "rate";
	
	private GeocoderHelper geoHelper;
	private Location geoLocation;
	private GoogleConnectionHelper GPSHelper;
	private Location GPSLocation = new Location("hgh");
	private String direccion;
	private String nombre;
	private LatLng posicionMarker;
	private String telefono;
	
	private Integer idMarker;
	private String nom;
	private String dir;
	private String observ;
	private String foto;
	private String tel;
	private Float rate;
	
	@Override
	protected void onStart() {
		
		GPSHelper = GoogleConnectionHelper.getInstance(this);
		geoHelper = new GeocoderHelper();
		
		super.onStart();
	}	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ver_todos);
		
		onStart();
		
		dbHelper = new RestauranteDB(getApplicationContext());
		db = dbHelper.getReadableDatabase();
		
		map = ((MapFragment)getFragmentManager().findFragmentById(R.id.fragment_map_todos)).getMap();
		
		Cursor cursor = db.rawQuery(DB_QUERY_ALL, null);
		cursor.moveToFirst();
		
		while (!cursor.isAfterLast()) {
			
			int nombreIndex = cursor.getColumnIndex("nombre");
			nombre = cursor.getString(nombreIndex);
			
			int telefonoIndex = cursor.getColumnIndex("telefono");
			telefono = cursor.getString(telefonoIndex);
			
			int direcIndex = cursor.getColumnIndex("direccion");
			direccion = cursor.getString(direcIndex);
			
			geoLocation = geoHelper.getLocation(direccion, getApplicationContext());
			posicionMarker = new LatLng(geoLocation.getLatitude(), geoLocation.getLongitude());
			
			Marker marker = map.addMarker(new MarkerOptions().position(posicionMarker).title(nombre).snippet(telefono));			
			cursor.moveToNext();
		}
		
		cursor.close();
		
		GPSLocation = GPSHelper.getLastLocation();
		
		if (GPSLocation.getLatitude() == 0 && GPSLocation.getLongitude() == 0) {
			posicionMarker = new LatLng(-34.603747, -58.381711);
			
			Marker now = map.addMarker(new MarkerOptions().position(posicionMarker).title("Obelisco").snippet("Obelisco"));
			map.moveCamera(CameraUpdateFactory.newLatLngZoom(posicionMarker, 15));
			map.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);
			now.showInfoWindow();
			
		} else {
			posicionMarker = new LatLng(GPSLocation.getLatitude(), GPSLocation.getLongitude());
			
			Marker now = map.addMarker(new MarkerOptions().position(posicionMarker).title("Posicion Actual").snippet("Posicion Actual"));
			map.moveCamera(CameraUpdateFactory.newLatLngZoom(posicionMarker, 15));
			map.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);
			now.showInfoWindow();
		}
		

		map.setInfoWindowAdapter(new InfoWindowAdapter() {
			
			@Override
			public View getInfoWindow(Marker arg0) {
				
				return null;
			}
			
			@Override
			public View getInfoContents(Marker arg0) {
				
				View v = getLayoutInflater().inflate(R.layout.activity_infowindow, null);
				
				TextView txtNombreInfo = (TextView)v.findViewById(R.id.nombreInfowindow);
				TextView txtDireccionInfo = (TextView)v.findViewById(R.id.direccionInfowindow);
				TextView txtTelefono = (TextView)v.findViewById(R.id.telefonoInfowindow);
				
				if (arg0.getTitle().toString().equalsIgnoreCase("Obelisco") || arg0.getTitle().toString().equalsIgnoreCase("Posicion Actual")) {
					
					txtNombreInfo.setText(arg0.getTitle().toString());
					txtDireccionInfo.setText("");
					txtTelefono.setText("");
					
				} else {
					
					Cursor cursorMarker = db.rawQuery(DB_QUERY_MARKER + arg0.getTitle().toString() + "'", null);
					cursorMarker.moveToFirst();
					while (!cursorMarker.isAfterLast()) {
						
						int direccionIndex = cursorMarker.getColumnIndex("direccion");
						direccion = cursorMarker.getString(direccionIndex);
						
						cursorMarker.moveToNext();
						
					}
					
					cursorMarker.close();
					
					txtNombreInfo.setText(arg0.getTitle().toString());
					txtTelefono.setText(arg0.getSnippet().toString());
					txtDireccionInfo.setText(direccion);
					
				}
								
				return v;
			}
		});
		
		
		map.setOnInfoWindowClickListener(new OnInfoWindowClickListener() {
			
			@Override
			public void onInfoWindowClick(Marker arg0) {
				
				if (arg0.getTitle().toString().equalsIgnoreCase("Obelisco") || arg0.getTitle().toString().equalsIgnoreCase("Posicion Actual")) {
					
				} else {
					
					Cursor cursordetalle = db.rawQuery(DB_QUERY_MARKER + arg0.getTitle().toString() + "'", null);
					cursordetalle.moveToFirst();
					
					while (!cursordetalle.isAfterLast()) {
						
						int idIndex = cursordetalle.getColumnIndex("id");
						idMarker = cursordetalle.getInt(idIndex);
						
						int nomIndex = cursordetalle.getColumnIndex("nombre");
						nom = cursordetalle.getString(nomIndex);
						
						int dirIndex = cursordetalle.getColumnIndex("direccion");
						dir = cursordetalle.getString(dirIndex);
						
						int observIndex = cursordetalle.getColumnIndex("observaciones");
						observ = cursordetalle.getString(observIndex);
						
						int fotoIndex = cursordetalle.getColumnIndex("foto");
						foto = cursordetalle.getString(fotoIndex);
						
						int telIndex = cursordetalle.getColumnIndex("telefono");
						tel = cursordetalle.getString(telIndex);
						
						int rateIndex = cursordetalle.getColumnIndex("rate");
						rate = cursordetalle.getFloat(rateIndex);
						
						cursordetalle.moveToNext();
						
					}
					
					cursordetalle.close();
					
					Bundle b = new Bundle();
					b.putInt(DB_COLUMN_1, idMarker);
					b.putString(DB_COLUMN_2, nom);
					b.putString(DB_COLUMN_3, dir);
					b.putString(DB_COLUMN_4, observ);
					b.putString(DB_COLUMN_5, foto);
					b.putString(DB_COLUMN_6, tel);
					b.putFloat(DB_COLUMN_7, rate);
					
					Intent i = new Intent(VerTodosActivity.this, DetalleActivity.class);
					i.putExtras(b);
					startActivity(i);
					
				}				
			}
		});
	
	}
}
