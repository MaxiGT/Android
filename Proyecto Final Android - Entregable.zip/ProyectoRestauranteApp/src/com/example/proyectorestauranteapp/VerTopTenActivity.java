package com.example.proyectorestauranteapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.R.integer;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.PointF;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class VerTopTenActivity extends FragmentActivity {
	
	public static final String DB_COLUMN_1 = "id";
	public static final String DB_COLUMN_2 = "nombre";
	public static final String DB_COLUMN_3 = "direccion";
	public static final String DB_COLUMN_4 = "observaciones";
	public static final String DB_COLUMN_5 = "foto";
	public static final String DB_COLUMN_6 = "telefono";
	public static final String DB_COLUMN_7 = "rate";
	public final static String DB_QUERY_ALL = "SELECT * FROM restaurante";
	// VAR ADAPTER LISTA
	private AdapterLista adapterLista;
	final ArrayList<RegistroDB> datosLista = new ArrayList<RegistroDB>();
	final ArrayList<RegistroDB> datosListafiltro = new ArrayList<RegistroDB>(10);
	// VAR GPS
	private GoogleConnectionHelper GPSHelper;
	private RestauranteDB dbHelper;
	private SQLiteDatabase db;
	private Location actualLocation;
	// VAR GEO
	private GeocoderHelper GeoHelper;
	private PointF destino = new PointF();
	private PointF actual = new PointF();
	private Location geoLocation;
	// VAR DISTANCIA
	private DistanceHelper mathHelper = new DistanceHelper(); 
	private Double distancia;
	//VAR DETALLE
	private int posicion;
	
	//EVENTO ON START
	@Override
	protected void onStart() {
		
		//INICIALIZACION HELPERS GPS y GEO
		GPSHelper = GoogleConnectionHelper.getInstance(this);
		GeoHelper = new GeocoderHelper();
		super.onStart();

	}

	//EVENTO ON CREATE
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ver_top_ten);
		
		//CASTEO DE CONTROLES
		ListView lstTopTen = (ListView)findViewById(R.id.listaTopTen);
		//INICIALIZACION EVENTO
		onStart();
		
		try {
			//INSTANCIACION DB
			dbHelper = new RestauranteDB(getApplicationContext());
			db = dbHelper.getWritableDatabase();
			//EJECUCION QUERY
			Cursor cursor = db.rawQuery(DB_QUERY_ALL, null);
			cursor.moveToFirst();
			
			while (!cursor.isAfterLast()) {
				
				//RECUPERO VALORES DE DB
				int IndexID = cursor.getColumnIndex(DB_COLUMN_1);				//ID
				Integer id = cursor.getInt(IndexID);
				
				int IndexNombre = cursor.getColumnIndex(DB_COLUMN_2);			//NOMBRE
				String nombre = cursor.getString(IndexNombre);
				
				int IndexDireccion = cursor.getColumnIndex(DB_COLUMN_3);		//DIRECCION
				String direccion = cursor.getString(IndexDireccion);
				
				int IndexObservaciones = cursor.getColumnIndex(DB_COLUMN_4);	//OBSERVACIONES
				String observaciones = cursor.getString(IndexObservaciones);
				
				int IndexFoto = cursor.getColumnIndex(DB_COLUMN_5);				//FOTO
				String foto = cursor.getString(IndexFoto);
				
				int IndexTelefono = cursor.getColumnIndex(DB_COLUMN_6);			//TELEFONO
				String telefono = cursor.getString(IndexTelefono);
				
				int IndexRate = cursor.getColumnIndex(DB_COLUMN_7);				//RATE
				Float rate = cursor.getFloat(IndexRate);
				
					try {
						
						//OBTENER LAT Y LONG PARA POINTF DESTINO
						geoLocation = GeoHelper.getLocation(direccion, getApplicationContext());
						destino.set(Float.valueOf(String.valueOf(geoLocation.getLatitude())), Float.valueOf(String.valueOf(geoLocation.getLongitude())));
						
						//OBTENER LAT Y LONG PARA POINTF ACTUAL
						actualLocation = GPSHelper.getActualLocation();
						actual.set(Float.valueOf(String.valueOf(actualLocation.getLatitude())), Float.valueOf(String.valueOf(actualLocation.getLongitude())));
						
						//CALCULO DE DISTANCIA
						distancia = mathHelper.getDistanceBetweenTwoPoints(actual, destino);
						
					} catch (Exception e) {
						
						//NO SE PUDO DISTANCIA 0.0 (DOUBLE)
						distancia = 0.0;
						
				}
				
				//AGREGO REGISTRORECUPERADO AL ARRAYLIST<REGISTRODB> DATOSLISTA
				RegistroDB registroNuevo = new RegistroDB(id, nombre, direccion, observaciones, foto, telefono, rate, distancia);
				datosLista.add(registroNuevo);
				//CICLO
				cursor.moveToNext();
				
			}
			//CIERRO CURSOR
			cursor.close();
			
			//ORDENO ARRAYLIST<REGISTRODB> DATOSLISTA
			Collections.sort(datosLista, new Comparator<RegistroDB>() {

				@Override
				public int compare(RegistroDB a, RegistroDB b) {
					return a.getDistancia().compareTo(b.getDistancia());
				}
			});
			
			//PASO PRIMEROS 10 POSICIONES A ARRAYLIST<REGISTRODB> DATOSLISTAFILTRO
			for (int i = 0; i < datosLista.size(); i++) {
				if (i < 10) {
					datosListafiltro.add(datosLista.get(i));
				} else {}
			}
			
			//SETEO ADAPTER CON DATOSLISTAFILTRO
			adapterLista = new AdapterLista(this, datosListafiltro);
			lstTopTen.setAdapter(adapterLista);
			
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(), "ERROR de Adapter", Toast.LENGTH_SHORT).show();
		}
		
		lstTopTen.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
						
				posicion = position;
				DialogHelperGenerico dialogFragment = DialogHelperGenerico
		                .newInstance("�Deseas ver el Detalle?", "Si", "No", "VerTopTenActivity");
		        dialogFragment.show(getSupportFragmentManager(), "dialog");
				return false;
			}
		});
	}
	
	public void doPositiveClick(){
		Bundle b = new Bundle();
		b.putLong(DB_COLUMN_1, datosLista.get(posicion).getId());
		b.putString(DB_COLUMN_2, datosLista.get(posicion).getNombre());
		b.putString(DB_COLUMN_3, datosLista.get(posicion).getDireccion());
		b.putString(DB_COLUMN_4, datosLista.get(posicion).getObservaciones());
		b.putString(DB_COLUMN_5, datosLista.get(posicion).getFoto());
		b.putString(DB_COLUMN_6, datosLista.get(posicion).getTelefono());
		b.putFloat(DB_COLUMN_7, datosLista.get(posicion).getRate());
		
		Intent intent = new Intent(getApplicationContext(), DetalleActivity.class);
		intent.putExtras(b);
		startActivity(intent);
    }
	
	public void doNegativeClick() {
		
	}
}
